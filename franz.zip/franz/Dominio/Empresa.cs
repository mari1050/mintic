namespace Dominio
{
    public class Empresa
    {
        
        public int ID {get;set; }
        public string Nombre { get; set; }

        public int Nit {get;set; }

        public string Ciudad { get; set; }

        public int Telefono {get;set; }
    }
}