numero1 = 10;
debugger;
if(numero1 < 11){
    console.log('estas en el condicional')
}